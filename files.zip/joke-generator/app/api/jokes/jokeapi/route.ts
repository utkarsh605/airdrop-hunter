import { NextRequest, NextResponse } from 'next/server';
import { fetchFromJokeAPI } from '@/lib/joke-service';

export async function GET(request: NextRequest) {
  try {
    const category = request.nextUrl.searchParams.get('category');
    const joke = await fetchFromJokeAPI(category || undefined);
    return NextResponse.json(joke);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch from JokeAPI' },
      { status: 500 }
    );
  }
}