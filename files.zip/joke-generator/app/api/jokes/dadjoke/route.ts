import { NextRequest, NextResponse } from 'next/server';
import { fetchDadJoke } from '@/lib/joke-service';

export async function GET(request: NextRequest) {
  try {
    const joke = await fetchDadJoke();
    return NextResponse.json(joke);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch dad joke' },
      { status: 500 }
    );
  }
}