import { NextRequest, NextResponse } from 'next/server';
import { fetchRandomJoke } from '@/lib/joke-service';

export async function GET(request: NextRequest) {
  try {
    const joke = await fetchRandomJoke();
    return NextResponse.json(joke);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch joke' },
      { status: 500 }
    );
  }
}