import { create } from 'zustand';
import { Joke } from './joke-service';

interface JokeStore {
  currentJoke: Joke | null;
  jokes: Joke[];
  favorites: Joke[];
  loading: boolean;
  error: string | null;
  category: string;
  
  setCurrentJoke: (joke: Joke | null) => void;
  addJoke: (joke: Joke) => void;
  addFavorite: (joke: Joke) => void;
  removeFavorite: (jokeId: string) => void;
  isFavorite: (jokeId: string) => boolean;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  setCategory: (category: string) => void;
  clearHistory: () => void;
}

export const useJokeStore = create<JokeStore>((set, get) => ({
  currentJoke: null,
  jokes: [],
  favorites: [],
  loading: false,
  error: null,
  category: 'Any',
  
  setCurrentJoke: (joke) => set({ currentJoke: joke }),
  
  addJoke: (joke) =>
    set((state) => ({
      jokes: [joke, ...state.jokes].slice(0, 50), // Keep last 50
    })),
  
  addFavorite: (joke) =>
    set((state) => {
      const exists = state.favorites.find((j) => j.id === joke.id);
      if (exists) return state;
      
      return {
        favorites: [joke, ...state.favorites],
      };
    }),
  
  removeFavorite: (jokeId) =>
    set((state) => ({
      favorites: state.favorites.filter((j) => j.id !== jokeId),
    })),
  
  isFavorite: (jokeId) => get().favorites.some((j) => j.id === jokeId),
  
  setLoading: (loading) => set({ loading }),
  
  setError: (error) => set({ error }),
  
  setCategory: (category) => set({ category }),
  
  clearHistory: () => set({ jokes: [] }),
}));