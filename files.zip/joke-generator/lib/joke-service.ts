import axios from 'axios';

export interface Joke {
  id: string;
  content: string;
  setup?: string;
  punchline?: string;
  type: 'single' | 'twopart';
  category: string;
  source: 'jokeapi' | 'dad-jokes' | 'random-user';
  timestamp: Date;
}

// JokeAPI.dev - Multiple categories and types
export async function fetchFromJokeAPI(category?: string): Promise<Joke> {
  try {
    const url = category
      ? `https://v2.jokeapi.dev/joke/${category}?type=single`
      : 'https://v2.jokeapi.dev/joke/Any?type=single';

    const response = await axios.get(url);
    const { joke, setup, delivery, category: jokeCategory, type } = response.data;

    return {
      id: `jokeapi-${Date.now()}`,
      content: joke || `${setup} ${delivery}`,
      setup,
      punchline: delivery,
      type: type === 'twopart' ? 'twopart' : 'single',
      category: jokeCategory || 'General',
      source: 'jokeapi',
      timestamp: new Date(),
    };
  } catch (error) {
    console.error('JokeAPI Error:', error);
    throw new Error('Failed to fetch from JokeAPI');
  }
}

// Dad Jokes API - Quick, simple jokes
export async function fetchDadJoke(): Promise<Joke> {
  try {
    const response = await axios.get('https://api.api-ninjas.com/v1/dadjokes', {
      headers: {
        'X-Api-Key': process.env.NEXT_PUBLIC_API_NINJAS_KEY || '',
      },
    });

    const joke = response.data[0];

    return {
      id: `dadjokes-${Date.now()}`,
      content: joke.joke,
      type: 'single',
      category: 'Dad Joke',
      source: 'dad-jokes',
      timestamp: new Date(),
    };
  } catch (error) {
    console.error('Dad Jokes API Error:', error);
    throw new Error('Failed to fetch from Dad Jokes API');
  }
}

// UselessFacts API Alternative - Fun facts as jokes
export async function fetchUselessFact(): Promise<Joke> {
  try {
    const response = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');

    return {
      id: `useless-${Date.now()}`,
      content: response.data.text,
      type: 'single',
      category: 'Useless Fact',
      source: 'random-user',
      timestamp: new Date(),
    };
  } catch (error) {
    console.error('Useless Facts Error:', error);
    throw new Error('Failed to fetch useless fact');
  }
}

// Fetch from random source
export async function fetchRandomJoke(): Promise<Joke> {
  const sources = [
    () => fetchFromJokeAPI(),
    () => fetchDadJoke(),
    () => fetchUselessFact(),
  ];

  const randomIndex = Math.floor(Math.random() * sources.length);
  return sources[randomIndex]();
}

// Fetch with specific category
export async function fetchJokeByCategory(category: string): Promise<Joke> {
  const validCategories = ['Programming', 'Knock-Knock', 'General', 'Misc', 'Christmas'];
  
  if (validCategories.includes(category)) {
    return fetchFromJokeAPI(category);
  }
  
  return fetchRandomJoke();
}