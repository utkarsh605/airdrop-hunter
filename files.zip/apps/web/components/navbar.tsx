'use client';

import { useNotificationStore } from '@/lib/store';
import { Bell, Search, User } from 'lucide-react';

export function Navbar() {
  const notifications = useNotificationStore((s) => s.notifications);
  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <nav className="bg-slate-800 border-b border-slate-700 px-6 py-4 flex items-center justify-between">
      <div className="flex-1 flex items-center gap-4">
        <div className="relative w-96">
          <input
            type="text"
            placeholder="Search airdrops..."
            className="input w-full pl-10"
          />
          <Search
            size={18}
            className="absolute left-3 top-2.5 text-slate-400"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative p-2 hover:bg-slate-700 rounded-lg transition-all">
          <Bell size={20} />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-5 h-5 bg-red-600 text-white text-xs rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>

        <button className="p-2 hover:bg-slate-700 rounded-lg transition-all">
          <User size={20} />
        </button>
      </div>
    </nav>
  );
}