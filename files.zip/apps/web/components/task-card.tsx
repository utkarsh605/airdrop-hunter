'use client';

import { useState } from 'react';
import { useMutation } from 'react-query';
import { AirdropTask } from '@/packages/db/src/types';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/lib/store';
import { ExternalLink, CheckCircle, Circle } from 'lucide-react';
import toast from 'react-hot-toast';

interface TaskCardProps {
  task: AirdropTask;
  projectId: string;
  isJoined: boolean;
}

export function TaskCard({ task, projectId, isJoined }: TaskCardProps) {
  const user = useAuthStore((s) => s.user);
  const [isCompleted, setIsCompleted] = useState(false);

  const completeTask = useMutation(
    async () => {
      if (!user) throw new Error('Not authenticated');

      await supabase.from('user_task_